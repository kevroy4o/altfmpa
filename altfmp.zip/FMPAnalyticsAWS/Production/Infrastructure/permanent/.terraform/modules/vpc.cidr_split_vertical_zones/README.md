# CIDR range splitter
This module splits a cidr range in evenly distributed non-overlapping sub-ranges.

## Usage
```hcl-terraform
module "ranges" {
  source = "git::ssh://code.siemens.com/modules/terraform/cidr-split"
  cidr_range = "10.0.0.0/8"
  range_count = 4
}
```

The module will now output 4 evenly distributed ranges:
"10.0.0.0/10"
"10.64.0.0/10"
"10.128.0.0/10"
"10.192.0.0/10"

If you input a non base 2 range count (like 12, 3, 5 etc.), The module starts over with the first subnet
and splits it in half and keeps on doing this with the next sub-ranges, until the desired count of ranges is reached.

e.g.: 

```hcl-terraform
module "ranges" {
  source = "git::ssh://code.siemens.com/modules/terraform/cidr-split"
  cidr_range = "10.0.0.0/8"
  range_count = 6
}
```

The output will be:
"10.0.0.0/11",
"10.32.0.0/11",
"10.64.0.0/11",
"10.96.0.0/11",
"10.128.0.0/10",
"10.192.0.0/10"


## Parameters

| Name        | Type   | Required? | Description                                                |
| ----------- | ------ | --------- | ---------------------------------------------------------- |
| cidr_range  | string | true      | The CIDR range to split                                    |
| range_count | string | true      | The number of CIDR ranges to generate from the given range |


## Outputs

| Name        | Type | Description                         |
| ----------- | ---- | ----------------------------------- |
| cidr_ranges | list | A list of the generated CIDR ranges |