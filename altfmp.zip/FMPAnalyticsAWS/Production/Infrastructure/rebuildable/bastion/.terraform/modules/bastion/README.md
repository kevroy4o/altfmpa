## Examples

Here is an example of how you can use this module in your inventory structure:
### Basic Example
```hcl
module "bastion" {
  source = "https://code.siemens.com/FMP_Analytics/fmp_analytics_infrastructure/modules/ec2-module/"
  ami_id = "ami-01854a07a17ea319e"
  instance_type = "t3.small"
  key_name = "bastion-key"
  api_termination = true
  user_data = "${path.module}/docs/ssm_linux_user.sh"
  security_group_ids = [ aws_security_group.bastion.id ]
  subnet_ids = [ data.terraform_remote_state.permanent.outputs.public_zone_subnet_ids[0] ]
  public_ip_address = true
  # private_ip = var.bastion_ip
  iam_instance_profile = ""
  tags = var.tags
  instance_name = "${var.resource_prefix}-dev-bastion"

  //root block
  volume_type = "gp2"
  volume_size = 200
  kms_key_id = ""
  encrypted = true

  // ebs-volume
  # ebs_volume_enabled = true
  # ebs_availability_zone = "us-east-1a"
  # ebs_volume_size = 350
  # ebs_volume_type = "gp2"
  # ebs_encrypted = true

}


## Outputs

| Name | Description |
|------|-------------|
| instance\_id | The instance ID. |


## Testing

You need to run the following command in the testing folder:
```hcl
  terraform init
  terraform plan
```

## Credits

Siemens CDS Team
