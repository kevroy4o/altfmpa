<a name="1.0.0"></a>
# [1.0.0](https://code.siemens.com/modules/terraform/aws/s3-bucket/-/tags/v1.0) (2019-01-21)

### Features

* initial release ([00e42ac1](https://code.siemens.com/modules/terraform/aws/s3-bucket/commit/00e42ac10efef034f3bd01f2f28ad04cb62e917b))


<a name="2.0.0"></a>
# [2.0.0](https://code.siemens.com/modules/terraform/aws/s3-bucket/-/tags/V2.0) (2019-06-15)

### Features

* upgrade to terraform 0.12 ([e27aaa84](https://code.siemens.com/modules/terraform/aws/s3-bucket/commit/e27aaa84a103808ed1ec3cc7765b57cde3ae2f91))

<a name="2.1.0"></a>
# [2.1.0](https://code.siemens.com/modules/terraform/aws/s3-bucket/-/tags/V2.1.0) (2019-09-13)

### Features

* added lifecycle features ([afb7df14](https://code.siemens.com/modules/terraform/aws/s3-bucket/commit/afb7df14ad863693fa845814d31232b84eb93d57))
* added capability to host static websites in an s3 bucket ([afb7df14](https://code.siemens.com/modules/terraform/aws/s3-bucket/commit/afb7df14ad863693fa845814d31232b84eb93d57))

<a name="2.2.0"></a>
# [2.2.0](https://code.siemens.com/modules/terraform/aws/s3-bucket/-/tags/V2.2.0) (2019-11-04)

### Features

* Allow to use owned logs bucket ([4eef0926](https://code.siemens.com/modules/terraform/aws/s3-bucket/commit/4eef09266eb582bddd4bc96c769033f045ed3844))

<a name="2.2.1"></a>
# [2.2.1](https://code.siemens.com/modules/terraform/aws/s3-bucket/-/tags/V2.2.1) (2019-11-06)

### Features

* Fixed output error ([c2c4599f](https://code.siemens.com/modules/terraform/aws/s3-bucket/commit/c2c4599f3f87f305b1f45ad7890c10156c2960be))
* Added capability to enable o disable ([37efe4e3](https://code.siemens.com/modules/terraform/aws/s3-bucket/commit/37efe4e375d96291a226cfc28189d7397bc628e7))

<a name="2.2.2"></a>
# [2.2.2](https://code.siemens.com/modules/terraform/aws/s3-bucket/-/tags/V2.2.2) (2019-11-07)

### Features

* Set a empty object bucket as an output when module is not enabled ([156d117b](https://code.siemens.com/modules/terraform/aws/s3-bucket/commit/156d117b4788896e32184bcf6652c5307db623b8))


<a name="2.3.1"></a>
# [2.3.1](https://code.siemens.com/modules/terraform/aws/s3-bucket/-/tags/V2.3.1) (2019-11-09)

### Features

* Block data bucket public access and public objects when bucket acl it's private. ([dd4237bc](https://code.siemens.com/modules/terraform/aws/s3-bucket/commit/dd4237bc091e79aa15907d5c6ef54e878c67e319))
* When a logging bucket is created, bucket public access and public objects are blocked. ([dd4237bc](https://code.siemens.com/modules/terraform/aws/s3-bucket/commit/dd4237bc091e79aa15907d5c6ef54e878c67e319))