<a name="2.1.0"></a>
# [2.1.0](https://code.siemens.com/modules/terraform/aws/ec2-instance-role/-/tags/V2.1.0)
- Change ssm policy to AmazonSSMManagedInstanceCore
