# FMP Analytics AWS

Automation of AWS instance setup for FMP Analytics

## Project status

- [x] Design Reference Architecture
- [X] Design Immutable Terraform scripts
- [X] Deploy and test Immutable Infrastructure using Iaac
- [x] Preprare Immutable resources documentation
- [X] Design Rebuidable Terraform scripts
- [X] Deploy and test Rebuildable Infrastructure using Iaac
- [ ] Preprare Rebuildable documentation
- [ ] Setting up customer Terraform
- [ ] Customer training on how to deploy Iaac using Terraform 

## Reference Architecture

The reference architeture is setup in two groups, being:

1. **Permanent or Immutable**
    
    Composed by those elements that do not change such as VPC, connectivity elements, etc.
    The Permanent infrastructure is compose by:
    - VPC
    - Public Subnet
    - Private Subnet
    - Security group
    - NAT Gateway
    - Internet Gateway
    - VPC Endpoint
    - IAM Roles 


2. **Rebuildable**
    
    Composed by those elements that can be destroyed and rebuilt as required.
    - Hardened AMI
    - EC2 instances ( bastion host and workload servers)
    - S3 buckets

The infrastructure diram can be seen at (https://code.klmit.com/daniel.regulin/FMPAnalyticsAWS/-/blob/main/FMPA_AWS_Schema.png)


## Installation
To apply the infrastruture just run the command below on you Terminal. It requires minimum Terraform version 1.x.x
```bash
$ terraform init -backend-config=config/backend.tfvars
$ terraform plan -var-file=config/parameters.tfvars
$ terraform apply -var-file=config/parameters.tfvars
```


## Iaac Files Detailing - File Maintenance Manual
1. **General**

1.1 main.tf

 Will contain the main set of configuration for your module. The main file defines:
 - AWS as provider, setting the region and profile as variables
 - backend S3
 - the aws caller kms_key_id

to see the snipet, expand below
 <details><summary>Click to expand</summary>

 ```
 provider "aws" {
  region  = var.region
  profile = var.profile
}

terraform {
  backend "s3" {
  }
}

data "aws_caller_identity" "current" {
}
```

</details>

----

1.2 variables.tf
 
 Will contain the variable definitions for your module. For FMPA project, variables were defined are:
 - ts (The ts to apply to all tgable resources)
 - profile (The profile from the shared credentials file to use)
 - region (The region to deploy the infrastructure to)
 - resource_prefix (A common resource prefix that should be used for resources created)
 - vpc_cidr (VPC cidr ip range)
 - bastion_ports
 - workload_ports

to see the snipet, expand below
<details><summary>Click to expand</summary>

```
#
# Base Variables
#
variable "ts" {
  description = "The ts to apply to all tgable resources"
  type        = map(string)
}

variable "profile" {
  description = "The profile from the shared credentials file to use"
  default     = ""
}

variable "region" {
  description = "The region to deploy the infrastructure to"
}

variable "resource_prefix" {
  description = "A common resource prefix that should be used for resources created"
}

variable "vpc_cidr" {
  description = "VPC cidr ip range"
}

variable "bastion_ports" {
  description = "bastion incoming ports"
  type        = list(string)
}

variable "workload_ports" {
  description = "bastion incoming ports"
  type        = list(string)
}

```

</details>

----

1.3 version.tf
 
 Will contain Terraform version

to see the snipet, expand below
<details><summary>Click to expand</summary>

```
terraform {
  required_version = ">= 1.0.0"
}
```

</details>

----

1.4 outputs.tf
  
 Contain de value of each outputs. The following outputs are available in this snipet:
 
 Base
 - vpc_id
 - main_kms_arn
 
 Subnets
 - public_zone_subnet_ids
 - workload_zone_subnet_ids
 - private_zone_subnet_ids
 
 Route tables
 - public_zone_route_table_id
 - private_zone_route_table_id
 - workload_zone_route_table_id

 Security groups
 - security_group_bastion
 - security_group_workload

 IAM policy
 - FMPA_ec2_instance_profile

to see the snipet, expand below
<details><summary>Click to expand</summary>

```
// Base
output "vpc_id" {
  value = module.vpc.vpc_id
}

output "main_kms_arn" {
  value = aws_kms_key.main.arn
}

// Subnets
output "public_zone_subnet_ids" {
  value = module.vpc.public_zone_subnet_ids
}
output "workload_zone_subnet_ids" {
  value = module.vpc.workload_zone_subnet_ids
}
output "private_zone_subnet_ids" {
  value = module.vpc.private_zone_subnet_ids
}

// Route tables
output "public_zone_route_table_id" {
  value = module.vpc.public_zone_route_table_id
}
output "workload_zone_route_table_id" {
  value = module.vpc.workload_zone_route_table_ids
}
output "private_zone_route_table_id" {
  value = module.vpc.private_zone_route_table_id
}

//Security Groups
output "security_group_bastion" {
  value = aws_security_group.bastion.id
}

output "security_group_workload" {
  value = aws_security_group.workload.id
}

// IAM policy
output "FMPA_ec2_instance_profile" {
  value = module.ec2-instance-role.ec2_instance_profile_name
}

// S3 bucket for access logging
#output "aws_s3_bucket_logging_bucket_id" {
#  value = aws_s3_bucket.logging_bucket.id
#}

#output "aws_s3_bucket_logging_bucket_arn" {
#  value = aws_s3_bucket.logging_bucket.arn
#}

```

</details>

----

2. **Config**

Config is composed by two files:

2.1 backend.tfvars

In the is file we define those variables which are going to be used by permanent Infrastructure.
For the FMP Analytics project we will have the following elements:
- S3 bucket to store the files generated
- Key for S3 bucket encryption
- Define the AWS region where the infrastructure is going to be deployed 
- DynamoDB table were terraform state is registered

to see the snipet, expand below
<details><summary>Click to expand</summary>

```
bucket = "fmpa-dev-test-iaac"
key = "permanent/permanent.tfstate"
region = "us-east-1"
encrypt = true
kms_key_id = "arn:aws:kms:us-east-1:111111111111:key/4cfadfcd-62c9-4707-9950-5d6f4e03e563"
dynamodb_table = "terraform-state-lock-dynamo"
```

</details>

----

2.2 parameters.tfvars

In this file we define the parameters which are fgoing to be used by permament Infrastructure.
For the FMP Analytics project we will have the following elements:
- region
- ts
- resource_prefix
- vpc_cidr
- bastion_ports
- workload_ports


to see the snipet, expand below
<details><summary>Click to expand</summary>

```
region = "us-east-1"

ts = {
  Project = "fmpa"
  Infrastructure = "Dev/Test"
  IaaCProject = "permanent"
  Name = "Dev/Test"
}

resource_prefix = "fmpa-dev-test"

#
# VPC
#

vpc_cidr = "10.0.0.0/16"

bastion_ports = [
  "22"
]

workload_ports = [
  "22",
  "9877",
  "6443"
]
```

</details>

----

3. **Permanent or Immutable**

3.1 kms_key_policy.json
 
 Contains the policy being used by the KMS key.
 
 This policy allows cloudwatch logs to use key for log encryption

to see the snipet, expand below

<details><summary>Click to expand</summary>

```
{
    "Version": "2012-10-17",
    "Id": "main-key",
    "Statement": [
        {
            "Sid": "Enable IAM User Permissions",
            "Effect": "Allow",
            "Principal": {
                "AWS": "arn:aws:iam::${account_id}:root"
            },
            "Action": "kms:*",
            "Resource": "*"
        },
        {
            "Sid": "Allow cloudwatch logs to use key for log encryption",
            "Effect": "Allow",
            "Principal": {
                "Service": "logs.${region}.amazonaws.com"
            },
            "Action": [
                "kms:Encrypt*",
                "kms:Decrypt*",
                "kms:ReEncrypt*",
                "kms:GenerateDataKey*",
                "kms:Describe*"
            ],
            "Resource": "*",
            "Condition": {
                "ArnLike": {
                    "kms:EncryptionContext:aws:logs:arn": "arn:aws:logs:${region}:${account_id}:*"
                }
            }
        }
    ]
}
```

</details>

----

3.2 remote_state.tf

 Contains the S3 bucket definitions.

to see the snipet, expand below

<details><summary>Click to expand</summary>

```
module "iaac_bucket" {
  source                  = "git::ssh://name@email.com/modules/terraform/aws/s3-bucket?ref=V2.3.1"
  ts                    = var.ts
  data_bucket_name        = "${var.resource_prefix}-iaac"
  data_bucket_use_kms     = true
  data_bucket_kms_key_arn = aws_kms_key.main.arn

  data_bucket_enable_versioning = true

  create_logging_bucket      = true
  logging_bucket_name        = "${var.resource_prefix}-iaac-access-logs"
  logging_bucket_use_kms     = true
  logging_bucket_kms_key_arn = aws_kms_key.main.arn

  logging_bucket_enable_log_transition_to_glacier = false

  logging_bucket_enable_log_deletion     = true
  logging_bucket_log_deletion_after_days = 180

  acl_public = false
}
```

</details>

----

3.3 resource_dynamodblock.tf

 Contains dynamodb table for terraform remote state locking

to see the snipet, expand below

<details><summary>Click to expand</summary>

```
// dynamodb table for terraform remote state locking

resource "aws_dynamodb_table" "dynamodb-terraform-state-lock" {
  name           = "terraform-state-lock-dynamo"
  hash_key       = "LockID"
  read_capacity  = 20
  write_capacity = 20
  attribute { 
    name = "LockID"
    type = "S"     
  }
  ts = merge(var.ts)
}
```

</details>

----

3.4 resource_ebs_encryption_default.tf

 Contains the EBS encryption by default settings

to see the snipet, expand below

<details><summary>Click to expand</summary>

```
data "aws_kms_key" "aws_maned_key" {
  key_id = "alias/aws/ebs"
}

resource "aws_ebs_encryption_by_default" "EbsDefaultEncryption" {
  enabled = true
}

resource "aws_ebs_default_kms_key" "EbsDefaultEncryption" {
  key_arn = data.aws_kms_key.aws_maned_key.arn
}
```

</details>

----

3.5 resources_kms.tf
 
  Contains the KMS key settings

to see the snipet, expand below

<details><summary>Click to expand</summary>

```
resource "aws_kms_key" "main" {
  description = "The main shared KMS key"
  policy = templatefile("${path.module}/kms_key_policy.json", {
    account_id = data.aws_caller_identity.current.account_id
    region     = var.region
  })
  ts = merge(var.ts, {
    Name = "${var.resource_prefix} main encryption key"
  })
  enable_key_rotation = true
}

resource "aws_kms_alias" "main" {
  target_key_id = aws_kms_key.main.id
  name          = "alias/${var.resource_prefix}-main"
}
```

</details>

----

3.6 resources_vpc.tf

 Contains the VPC settings.

 **IMPORTANT** check the code, it refers to an existing VPC, which is the current reference VPC architecture 
 
 code.klmit.com/modules/terraform/aws/vpc?ref=v4.0.1

to see the snipet, expand below 

<details><summary>Click to expand</summary>

```
# VPC Section 

## VPC
module "vpc" {
  source = "git::ssh://name@email.com/modules/terraform/aws/vpc?ref=v4.0.1"

  ts = merge(var.ts)

  vpc_cidr_block                      = var.vpc_cidr
  number_of_availability_zones_to_use = 2
  provide_public_zone                 = true
  provide_private_zone                = true
  enable_nat_gateway                  = true
  enable_dns_support                  = true
  enable_dns_hostnames                = true

}
```

</details>

----

3.7 resource_s3_endppoint.tf

 Contains the S3 endppoint settings.

to see the snipet, expand below 

<details><summary>Click to expand</summary>

```
resource "aws_vpc_endpoint" "s3" {
  vpc_id       = module.vpc.vpc_id
  service_name = "com.amazonaws.us-east-1.s3"
}

resource "aws_vpc_endpoint_route_table_association" "s3_rt_endpoint" {
  route_table_id  = module.vpc.workload_zone_route_table_ids[0]
  vpc_endpoint_id = aws_vpc_endpoint.s3.id
}

resource "aws_vpc_endpoint_policy" "example" {
  vpc_endpoint_id = aws_vpc_endpoint.s3.id
  policy = jsonencode({
    "Version" : "2012-10-17",
    "Statement" : [
      {
        "Sid" : "AllowAll",
        "Effect" : "Allow",
        "Principal" : {
          "AWS" : "*"
        },
        "Action" : [
          "s3:*"
        ],
        "Resource" : "*"
      }
    ]
  })
}
```

</details>

----

3.8 resource_security_group_bastion.tf

 Contains the security Group for the bastion host access.

to see the snipet, expand below 

<details><summary>Click to expand</summary>

```
#
# bastion host
#
resource "aws_security_group" "bastion" {
  name = "bastion"
  description = "bastion SG"
  vpc_id = module.vpc.vpc_id

  ts = merge({
  Name = "${var.resource_prefix}-dev-bastion"
  }, var.ts)
}

// Incoming rule
resource "aws_security_group_rule" "bastion-incoming" {
  description = "Inbound rules to bastion host"
  count = length(var.bastion_ports)
  type = "ingress"
  from_port = element(var.bastion_ports, count.index)
  to_port = element(var.bastion_ports, count.index)
  protocol = "tcp"
  cidr_blocks = ["0.0.0.0/0"]
  security_group_id = aws_security_group.bastion.id
}

// Outbound rule
resource "aws_security_group_rule" "bastion-outbound" {
  type = "egress"
  description = "Outbound rules to bastion"
  from_port = 0
  to_port = 0
  protocol = -1
  cidr_blocks = ["0.0.0.0/0"]
  security_group_id = aws_security_group.bastion.id
}
```

</details>

----

3.9 resource_security_group_workload.tf

 Contains the security Group for the workload access.

to see the snipet, expand below 

<details><summary>Click to expand</summary>

```
# workload group hosts SG
# 
resource "aws_security_group" "workload" {
  name = "workload"
  description = "workload SG"
  vpc_id = module.vpc.vpc_id

  ts = merge({
  Name = "${var.resource_prefix}-dev-workload-SG"
  }, var.ts)
}

// Incoming rule
resource "aws_security_group_rule" "workload-incoming" {
  description = "Inbound rules to workload hosts"
  count = length(var.workload_ports)
  type = "ingress"
  from_port = element(var.workload_ports, count.index)
  to_port = element(var.workload_ports, count.index)
  protocol = "tcp"
  cidr_blocks = ["0.0.0.0/0"]
  security_group_id = aws_security_group.workload.id
}

// Outbound rule
resource "aws_security_group_rule" "workload-outbound" {
  type = "egress"
  description = "Outbound rules from workload group"
  from_port = 0
  to_port = 0
  protocol = -1
  cidr_blocks = ["0.0.0.0/0"]
  security_group_id = aws_security_group.workload.id
}
```

</details>

----

3.10 resources_iam.tf

 Contains the instance role and its permissions

to see the snipet, expand below 

<details><summary>Click to expand</summary>

```
# IAM Role
#
module "ec2-instance-role" {
  source = "git::ssh://name@email.com/modules/terraform/aws/ec2-instance-role"
  ts = var.ts
  name = "FMPA_workload_instance_role"
  attach_policy_arns = [
    "arn:aws:iam::aws:policy/CloudWatchLogsFullAccess",
    "arn:aws:iam::aws:policy/AmazonSSMManedInstanceCore",
    "arn:aws:iam::aws:policy/AmazonS3FullAccess"
  ]
}
```

</details>
