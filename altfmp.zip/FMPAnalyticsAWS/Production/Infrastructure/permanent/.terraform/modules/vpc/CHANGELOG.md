<a name="1.0.0"></a>
# [1.0.0](https://code.siemens.com/modules/terraform/aws/vpc/-/tags/V1.0) (2019-07-05)
- initial release, compatible with Terraform prior to v0.12

<a name="2.0.1"></a>
# [2.0.1](https://code.siemens.com/modules/terraform/aws/vpc/-/tags/v2.0.1) (2019-08-14)
- changed code base to be compatible with Terraform v0.12

<a name="2.1.0"></a>
# [2.1.0](https://code.siemens.com/modules/terraform/aws/vpc/-/tags/V2.1.0) (2019-10-08)
- added input parameter "blacklisted_availability_zone_ids" = List of availability zones IDs that the created VPC must not use. This is useful, for example, in case you use EC2 instance types that are not yet available in all availability zones of a region.

<a name="2.2.0"></a>
# [2.2.0](https://code.siemens.com/modules/terraform/aws/vpc/-/tags/V2.2.0) (2019-11-06)
- Support configuration of different tags for public, workload and private zone.

<a name="2.2.1"></a>
# [2.2.1](https://code.siemens.com/modules/terraform/aws/vpc/-/tags/V2.2.1) (2020-07-23)
- change vpc pictures to resemble a more accurate state
- added first vpc example (public and private)

<a name="3.0.0"></a>
# [3.0.0](https://code.siemens.com/modules/terraform/aws/vpc/-/tags/V3.0.0) (2020-08-05)
- update module to make it compatible with terraform aws provider version >= 3.0.0

<a name="4.0.0"></a>
# [4.0.0](https://code.siemens.com/modules/terraform/aws/vpc/-/tags/V4.0.0) (2021-03-09)
- update module to make it compatible with terraform v0.14
- added second vpc example (2 workload subnets + 2 private subnets)

<a name="4.0.0"></a>
# [4.0.1](https://code.siemens.com/modules/terraform/aws/vpc/-/tags/V4.0.1) (2022-05-27)
- add new outputs: vpc_main_route_table_id, vpc_default_security_group_id
