# Module "ec2-instance-role"
Creates an AWS IAM role to be used by EC2 instances. This mechanism is used to grant AWS EC2 instances permissions to interact with AWS resources and services without the need to supply them with hardcoded access keys or other form of passwords. Further information on this topic is available at the following URL:

https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/iam-roles-for-amazon-ec2.html

In order to grant the instance profile specific permissions that make sense for your use case, you pass IAM policies as a module parameter, which will then be attached to the instance role. In addition, two AWS-managed policies are attached to the instance role by default (can be disabled):
- AmazonEC2RoleforSSM (to allow communication with the AWS Systems Manager)
- CloudWatchAgentServerPolicy (to allow communication of the CloudWatch Logs agent)

Please note that AWS IAM is a global service. Deployed instance roles are thus available in all regions of an account. The module can be deployed multiple times in order to create instance roles with different sets of permissions.


# Example
```
module "ec2-instance-role" {
  source = "git::ssh://git@code.siemens.com/modules/terraform/aws/ec2-instance-role"
  tags = { 
    Project = "MyProject"
    Scope = "PROD"
  }
  name = "MyInstanceRole"
  attach_policy_arns = [
    "arn:aws:iam::aws:policy/AmazonAthenaFullAccess",
    "arn:aws:iam::aws:policy/AmazonChimeReadOnly"
  ]
}
```


# Parameters
| Name | Required? | Description |
| ------ | ------ | ------ |
| tags | yes | A map of tags that will be assigned to all AWS resources created by this module that support tagging. |
| attach_policy_arns | no | List of IAM policy ARNs to be attached to the instance role created. The policies can either be AWS-managed policies or customer-managed policies you created previously outside of this module. The default is an empty list, which then only attaches the default policies for AWS Systems Manager and the CloudWatch Logs agent (see parameters below). A maximum of 8 policies can be specified in the list (or 10 if the two default policies below are disabled). |
| attach_policy_for_systems_manager | no | Attaches the AWS-managed policy "AmazonEC2RoleforSSM" to the instance role. Default: true. |
| attach_policy_for_cloudwatch_agent | no | Attaches the AWS-managed policy "CloudWatchAgentServerPolicy" to the instance role. Default: true. |


# Outputs
| Name | Description |
| ------ | ------ |
| iam_role_name | The name of the IAM role created. |
| iam_role_arn | The ARN of the IAM role created. |
| ec2_instance_profile_name | The name of the instance profile that is backed by the IAM role created. This is used when launching an EC2 instance. |
| ec2_instance_profile_arn | The ARN of the instance profile that is backed by the IAM role created. This is used when launching an EC2 instance. |


# AWS services and resources used by this module
- IAM
