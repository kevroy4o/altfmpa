# Module "vpc"
Provisions an AWS VPC (Virtual Private Cloud) with network separation in accordance to the Siemens cloud reference architecture. 

> The VPC cannot be created using Terraform but only be imported, and needs to be requested by the central DEC team.
> To use a VPC request a CIDR with the DEC team!   

![architecture](img/vpc.png "architecture")

Overall, the cloud reference architecture consists of three network zones. Please note that it is not required to use all these zones: depending on your workload only a subset may be used.
1. *Public zone:* This network zone is connected to the public Internet via an AWS Internet Gateway. Systems that live here have a public IP address and can communicate with other systems on the Internet. Example systems that are operated in this zone: Load balancers, squid proxy systems and bastion hosts. This network zone is optional. Systems that live in this zone can communicate with other systems in the workload zone (if your security groups allow this), but by default cannot communicate with systems in the private zone.
2. *Workload zone:* This network zone is neither directly connected to the Internet nor to the Siemens Intranet. Systems that live in this zone do not have a public IP address associated. Example systems that are operated in this zone: web servers behind a load balancer, application servers and database servers. This network zone is mandatory and does always exist. Systems that live in this zone can communicate with other systems in both the public zone and the private zone (if your security groups allow this). If connectivity between systems in this zone and the Internet or the Siemens Intranet shall be established, this needs to happen via systems placed in the public zone or the private zone (e.g. via AWS NAT gateways or squid proxies).
3. *Private zone:* This network zone is meant for communication towards the Siemens Intranet, for example via VPN connectivity or Direct Connect, and towards other AWS accounts, for example via VPC peering or PrivateLink. Please note that this module only provides the network zone for such connectivity, but does not set up actual VPN connections or Direct connect. Please reach out to DEC for setting this up. Example systems that are operated in this zone: Load balancers, squid proxy systems and bastion hosts. This network zone is optional. Systems that live in this zone can communicate with other systems in the workload zone (if your security groups allow this), but by default cannot communicate with systems in the public zone.

Please note the following additional aspects of this module:
* This module only provisions an Internet Gateway if it is configured to create a public zone for the VPC. By default, only subnets belonging to the public zone have a route configured towards the Internet Gateway.
* Optionally, this module also provisions AWS NAT gateways to allow communication from the workload zone, via the public zone towards the Internet. This feature is only available if a public zone is configured. Depending on your information security requirements, you may need to go for squid proxies instead of NAT gateways.
* This module provisions network access control lists (NACLs) to prevent direct communication between subnets of the public zone and subnets of the private zone. While the module provides an option to disable this separation, it is highly recommended not to do so, as this can lower the overall security posture of your setup. Apart from this separation via NACLs, different subnets within a VPC can reach each other by default. Thus, it is highly recommended to use AWS security groups to restrict network connectivity as individually required by your workload. Example: use security groups to restrict that web servers in your workload zone can only be reached by a specific load balancer in the public zone.
* As described above, systems in the workload zone by default are fenced off without connectivity to the Internet or native AWS services. If connectivity is desired, please provision respective proxy systems or AWS VPC endpoints.


# Example
```
module "vpc" {
  source = "git::ssh://git@code.siemens.com/modules/terraform/aws/vpc"
  tags = { 
    Project = "MyProject"
    Scope = "PROD"
  }
  vpc_cidr_block = "10.0.0.0/16"
  number_of_availability_zones_to_use = 2
  provide_public_zone = true
  provide_private_zone = true
}
```

With secondary CIDR blocks:
```
module "vpc" {
  source = "git::ssh://git@code.siemens.com/modules/terraform/aws/vpc"
  tags = { 
    Project = "MyProject"
    Scope = "PROD"
  }
  vpc_cidr_block = "10.0.0.0/16"
  secondary_cidr_blocks = ["10.2.0.0/16"]
  use_custom_subnet_cidr_blocks = true
  public_zone_custom_subnet_cidr_blocks = ["10.2.0.0/17", "10.2.128.0/17"]
  private_zone_custom_subnet_cidr_blocks = ["10.0.0.0/18", "10.0.64.0/18"]
  workload_zone_custom_subnet_cidr_blocks = ["10.0.128.0/18", "10.0.192.0/18"]
  number_of_availability_zones_to_use = 2
  provide_public_zone = true
  provide_private_zone = true
}
```


# Parameters
| Name | Required? | Description |
| ------ | ------ | ------ |
| tags | yes | A map of tags that will be assigned to all AWS resources created by this module that support tagging. |
| vpc_cidr_block | yes | The IPv4 CIDR block that the created VPC will use. All network zones and subnets therein will get a share of this IP space. |
| secondary_cidr_blocks | no | A list of secondary CIDR blocks to assign to the VPC. |
| number_of_availability_zones_to_use | yes | The number of subnets to create within a network zone. In AWS, one subnet belongs to one specific availability zone. For resiliency purposes, you should choose a minimum of 2 for this setting. The number of total availability zones available depends on the AWS region used. Further details are available at the following URL: https://aws.amazon.com/about-aws/global-infrastructure/ |
| blacklisted_availability_zone_ids | List of availability zones IDs that the created VPC must not use. This is useful, for example, in case you use EC2 instance types that are not yet available in all availability zones of a region. You can retrieve a mapping between availability zone names of your account and actual availability zone IDs by, for example, ``aws ec2 describe-availability-zones``. Example: ["euc1-az3"]. Default: empty list. |
| provide_public_zone | yes | Boolean value to indicate whether a public zone shall be created for this VPC. The zone will consist of a number of subnets configured in ``number_of_availability_zones_to_use``.  If set to true, an Internet Gateway is created along and referenced in the route table of the subnets in the public zone. |
| provide_private_zone | yes | Boolean value to indicate whether an private zone shall be created for this VPC. The zone will consist of a number of subnets configured in ``number_of_availability_zones_to_use``. |
| public_zone_tags | no | Map of tags to apply to the subnets of the public zone |
| private_zone_tags | no | Map of tags to apply to the subnets of the private zone |
| workload_zone_tags | no | Map of tags to apply to the subnets of the workload zone |
| instance_tenancy | no | Use this option to control whether instances launched in this VPV should run on dedicated hardware. Further details are available at the following URL: https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/dedicated-instance.html#dedicated-howitworks Default: "default". |
| enable_dns_support | no | Boolean value to indicate whether DNS resolution is supported within the VPC. Further details are available at the following URL: https://docs.aws.amazon.com/vpc/latest/userguide/vpc-dns.html#vpc-dns-support Default: "true". |
| enable_dns_hostnames | no | Boolean value to indicate whether instances launched in the VPC will get public DNS host names. Further details are available at the following URL: https://docs.aws.amazon.com/vpc/latest/userguide/vpc-dns.html#vpc-dns-support Default: "true". |
| enable_nat_gateway | no | Boolean value to indicate whether an AWS NAT gateway shall be provisioned. If this parameter is set to "true", an AWS NAT gateway is provisioned and added to the route table of the workload zone. This essentially provides Internet access to systems operated in the workload zone. Please note that only one NAT gateway is provisioned (single AZ), but it is used by all subnets in the workload zone. For a higher degree of availability, use the parameter ``provision_nat_gateways_in_multiple_azs``. This parameter only takes effect if ``provide_public_zone`` is set to "true". Default: "false". |
| provision_nat_gateways_in_multiple_azs | no | Boolean value to indicate that multiple AWS NAT gateways shall be provisioned (one per AZ), instead of only one. Each subnets route table will have a route towards the NAT gateway in the same AZ. This parameter only takes effect if the parameters ``provide_public_zone`` and ``enable_nat_gateway`` are set to "true". Default: "false". |
| use_custom_subnet_cidr_blocks | no | By default, this module takes the CIDR range configured in ``vpc_cidr_block`` and splits it into fair shares to accomodate the desired network zones and the desired number of availability zones. If this is not desired and a manual split shall be applied, set this variable to "true". Setting this variable to "true" makes it mandatory to also specify the variables ``public_zone_custom_subnet_cidr_blocks``, ``workload_zone_custom_subnet_cidr_blocks`` and ``private_zone_custom_subnet_cidr_blocks``. Default: "false". |
| public_zone_custom_subnet_cidr_blocks | no | This variable needs to be configured when both ``provide_public_zone`` and ``use_custom_subnet_cidr_blocks`` are set to "true". Provide a list of CIDR ranges to be used for the subnets in the public network zone. The length of the list must equal the number of availability zones configured in ``number_of_availability_zones_to_use``. Example: ["10.0.1.0/24", "10.0.2.0/24"] |
| workload_zone_custom_subnet_cidr_blocks | no | This variable needs to be configured when ``use_custom_subnet_cidr_blocks`` is set to "true". Provide a list of CIDR ranges to be used for the subnets in the workload network zone. The length of the list must equal the number of availability zones configured in ``number_of_availability_zones_to_use``. Example: ["10.0.10.0/24", "10.0.11.0/24"] |
| private_zone_custom_subnet_cidr_blocks | no | This variable needs to be configured when both ``provide_private_zone`` and ``use_custom_subnet_cidr_blocks`` are set to "true". Provide a list of CIDR ranges to be used for the subnets in the private network zone. The length of the list must equal the number of availability zones configured in ``number_of_availability_zones_to_use``. Example: ["10.0.40.0/24", "10.0.41.0/24"] |
| enable_nacl_separation_between_public_and_intranet_zone | no | Boolean value to indicate whether subnets from the public and the private zone shall be separated from each other via network access control lists (NACLs). It is highly recommended not to change this setting, as this can lower the overall security posture of your setup. Default: true. |



# Outputs
| Name | Description |
| ------ | ------ |
| vpc_arn | The ARN of the VPC created. |
| vpc_id | The ID value of VPC created. | 
| internet_gateway_id | The ID value of the Internet Gateway created. This value is only populated when ``provide_public_zone`` is set to "true". |
| public_zone_subnet_arns | List of ARNs of subnets created in the public zone. This value is only populated when ``provide_public_zone`` is set to "true". |
| public_zone_subnet_ids | List of ID values of subnets created in the public zone. This value is only populated when ``provide_public_zone`` is set to "true". |
| public_zone_subnet_cidrs | List of CIDR blocks of subnets created in the public zone. This value is only populated when ``provide_public_zone`` is set to "true". |
| public_zone_route_table_id | The ID value of the route table referenced by subnets in the public zone. This value is only populated when ``provide_public_zone`` is set to "true". |
| public_zone_nacl_id | The ID value of the network access control list (NACL) applied to subnets in the public zone. This value is only populated when ``provide_public_zone`` is set to "true". |
| workload_zone_subnet_arns | List of ARNs of subnets created in the workload zone. |
| workload_zone_subnet_ids | List of ID values of subnets created in the workload zone. |
| workload_zone_subnet_cidrs | List of CIDR blocks of subnets created in the workload zone. |
| workload_zone_route_table_ids | List of route table IDs referenced by subnets in the workload zone. The list consists of more than one entry in case NAT gateways are provisioned in multiple AZs. |
| workload_zone_nacl_id | The ID value of the network access control list (NACL) applied to subnets in the workload zone. |
| private_zone_subnet_arns | List of ARNs of subnets created in the private zone. This value is only populated when ``provide_private_zone`` is set to "true". |
| private_zone_subnet_ids | List of ID values of subnets created in the private zone. This value is only populated when ``provide_private_zone`` is set to "true". |
| private_zone_subnet_cidrs | List of CIDR blocks of subnets created in the private zone. This value is only populated when ``provide_private_zone`` is set to "true". |
| private_zone_route_table_id | The ID value of the route table referenced by subnets in the private zone. This value is only populated when ``provide_private_zone`` is set to "true". |
| private_zone_nacl_id | The ID value of the network access control list (NACL) applied to subnets in the private zone. This value is only populated when ``provide_private_zone`` is set to "true". |
| nat_gateway_ids | List of IDs of the NAT gateways created. The list consists of more than one entry in case NAT gateways are provisioned in multiple AZs. |
| nat_gateway_network_interface_ids | List of network interface IDs of the NAT gateways created. The list consists of more than one entry in case NAT gateways are provisioned in multiple AZs. |
| vpc_main_route_table_id | ID of the VPC's main route table |
| vpc_default_security_group_id | ID of the VPC's default security group |


# AWS services and resources used by this module
- VPC

