# #!/bin/bash

# bastion host if needed for user data here