#!/bin/bash

# set -x

#git, python3, apt, dpkg, nano, vim already installed on Debian10
sudo apt update
sudo apt-get update

#install telnet
sudo apt install telnet

#install pip3
sudo apt install python3-pip -y

#Docker installs
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh
curl -s https://api.github.com/repos/docker/compose/releases/latest | grep browser_download_url  | grep docker-compose-linux-x86_64 | cut -d '"' -f 4 | wget -qi -
chmod +x docker-compose-linux-x86_64
sudo mv docker-compose-linux-x86_64 /usr/local/bin/docker-compose

#microsoft .net and sdk installs
wget https://packes.microsoft.com/config/debian/10/packes-microsoft-prod.deb -O packes-microsoft-prod.deb
sudo dpkg -i packes-microsoft-prod.deb
rm packes-microsoft-prod.deb
sudo apt-get install -y apt-transport-https && \
  sudo apt-get update && \
  sudo apt-get install -y dotnet-sdk-6.0

#GNU CC compiler
sudo apt install build-essential -y

# Config SSM ent for AWS Systems Maner Control by t
mkdir /tmp/ssm
cd /tmp/ssm
wget https://s3.amazonaws.com/ec2-downloads-windows/SSMent/latest/debian_amd64/amazon-ssm-ent.deb
sudo dpkg -i amazon-ssm-ent.deb
sudo systemctl enable amazon-ssm-ent

# Additional user data
# ${additional_user_data_script}