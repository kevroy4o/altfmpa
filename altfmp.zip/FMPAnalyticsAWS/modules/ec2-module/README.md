## Examples

Here is an example of how you can use this module in your inventory structure:
### Basic Example
```hcl
module "bastion" {
  source = "https://code.klmit.com/FMP_Analytics/fmp_analytics_infrastructure/modules/ec2-module/"
  ami_id = "ami-01854a07a17ea319e"
  instance_type = "t3.small"
  key_name = "bastion-key"
  api_termination = true
  user_data = "${path.module}/docs/ssm_linux_user.sh"
  security_group_ids = [ aws_security_group.bastion.id ]
  subnet_ids = [ data.terraform_remote_state.permanent.outputs.public_zone_subnet_ids[0] ]
  public_ip_address = true
  # private_ip = var.bastion_ip
  iam_instance_profile = ""
  ts = var.ts
  instance_name = "${var.resource_prefix}-dev-bastion"

  //root block
  volume_type = "gp2"
  volume_size = 200
  kms_key_id = ""
  encrypted = true

  // ebs-volume
  # ebs_volume_enabled = true
  # ebs_availability_zone = "us-east-1a"
  # ebs_volume_size = 350
  # ebs_volume_type = "gp2"
  # ebs_encrypted = true

}

#
# bastion host
# 
resource "aws_security_group" "bastion" {
  name = "bastion"
  description = "bastion SG"
  vpc_id = data.terraform_remote_state.permanent.outputs.vpc_id

  ts = merge({
  Name = "${var.resource_prefix}-dev-bastion"
  }, var.ts)
}

// Incoming rule
resource "aws_security_group_rule" "bastion-incoming" {
  description = "Inbound rules to bastion host"
  count = length(var.bastion_ports)
  type = "ingress"
  from_port = element(var.bastion_ports, count.index)
  to_port = element(var.bastion_ports, count.index)
  protocol = "tcp"
  cidr_blocks = ["0.0.0.0/0"]
  security_group_id = aws_security_group.bastion.id
}

// Outbound rule
resource "aws_security_group_rule" "bastion-outbound" {
  type = "egress"
  description = "Outbound rules to bastion"
  from_port = 0
  to_port = 0
  protocol = -1
  cidr_blocks = ["0.0.0.0/0"]
  security_group_id = aws_security_group.bastion.id
}
```


## Outputs

| Name | Description |
|------|-------------|
| instance\_id | The instance ID. |
| instance\_sg | security group for the instance. |


## Testing

You need to run the following command in the testing folder:
```hcl
  terraform init
  terraform plan
```

## Credits

GFY AWS Cloud Team
