# Module "s3-bucket"
Creates an AWS S3 bucket pre-configured with encryption and access logging. The module provides two AWS buckets: a data bucket where your actual data goes and a logging bucket where all log information regarding the data bucket will be stored. By default, both buckets are encrypted using AWS S3-managed encryption keys (SSE-S3), but can be configured to use AWS KMS-based encryption instead (with a KMS key you provide). Configuration of automated archival or deletion of old log files is available via optional parameters.

To use bucket policies on the created buckets, use the following Terraform resource and reference to the output of this module:
https://www.terraform.io/docs/providers/aws/r/s3_bucket_policy.html

> It is possible that you want to create a S3 bucket, only under some conditions. To deal with this problem, the variable **enabled** must be set up as false.

# Example
```
module "s3-bucket" {
  source = "git::ssh://git@code.siemens.com/modules/terraform/aws/s3-bucket"
  tags = { 
    Project = "MyProject"
    Scope = "PROD"
  }
  data_bucket_name = "my-bucket-124532353657"
  data_bucket_use_kms = true
  data_bucket_kms_key_arn = aws_kms_key.my_kms_key.arn
  website = {
    index_document = "index.html"
    error_document = "error.html"
    routing_rules = jsonencode([{
      Condition : {
        KeyPrefixEquals : "docs/"
      },
      Redirect : {
        ReplaceKeyPrefixWith : "documents/"
      }
    }])

  }
  lifecycle_rule = [
    {
      id      = "log"
      enabled = true
      prefix  = "log/"

      tags = {
        rule      = "log"
        autoclean = "true"
      }

      transition = [
        {
          days          = 30
          storage_class = "ONEZONE_IA"
          }, {
          days          = 60
          storage_class = "GLACIER"
        }
      ]

      expiration = {
        days = 90
      }

      noncurrent_version_expiration = {
        days = 30
      }
    },
    {
      id                                     = "log1"
      enabled                                = true
      prefix                                 = "log1/"
      abort_incomplete_multipart_upload_days = 7

      noncurrent_version_transition = [
        {
          days          = 30
          storage_class = "STANDARD_IA"
        },
        {
          days          = 60
          storage_class = "ONEZONE_IA"
        },
        {
          days          = 90
          storage_class = "GLACIER"
        },
      ]

      noncurrent_version_expiration = {
        days = 300
      }
    },
  ]
}
```


# Parameters
| Name | Required? | Description |
| ------ | ------ | ------ |
| tags | yes | A map of tags that will be assigned to all AWS resources created by this module that support tagging. |
| data_bucket_name | yes | Name of the S3 bucket where you will store your data to. |
| data_bucket_enable_versioning | no | Turn on versioning for all objects stored in the data bucket. Default: false. |
| data_bucket_use_kms | no | Turn on KMS-based encryption for the data bucket, instead of SSE-S3-based encryption. Setting this parameter to true requires you to to specify the "data_bucket_kms_key_arn" parameter. Default: false. |
| data_bucket_kms_key_arn | no | The KMS key to use when the "data_bucket_use_kms" parameter is specified. |
| create_logging_bucket | no | Indicates if it's necesary to create a bucket to store access logs for the new bucket. If not, you must set the name of the bucket where you want to store the access logs "logging_bucket_name" |
| logging_bucket_name | no | Name of the S3 bucket where access logs regarding the data bucket will be stored. Default: "[DATA-BUCKET-NAME]-access-logs". |
| logging_bucket_use_kms | no | Turn on KMS-based encryption for the logginh bucket, instead of SSE-S3-based encryption. Setting this parameter to true requires you to to specify the "logging_bucket_kms_key_arn" parameter. Default: false. |
| logging_bucket_kms_key_arn | no | The KMS key to use when the "logging_bucket_use_kms" parameter is specified. Default: "". |
| logging_bucket_enable_log_transition_to_glacier | no | Enables transition of log information stored in the logging bucket to AWS Glacier for long-term storage at reduced cost. Default: true. |
| logging_bucket_log_transition_to_glacier_after_days | no | The number of days after which a log file object is transitioned to AWS Glacier. This only applies if the "logging_bucket_enable_log_transition_to_glacier" parameter is enabled. Default: 365. |
| logging_bucket_enable_log_deletion | no | Enables automated deletion of old log objects in the logging bucket. Default: false. |
| logging_bucket_log_deletion_after_days | no | The number of days after which a log object is deleted. This only applies if the "logging_bucket_enable_log_deletion" parameter is enabled. Default: 1095. |
| s3_force_destroy_buckets | no | S3 does not allow deleting buckets that contain objects. This is the desired behavior for production landscapes, as it prevents unintended deletion of potentially important content, such as logs. However, when using CICD or working in test environments, it may be desirable to force the deletion of buckets, although they contain objects. This scenario is supported by setting this parameter to true. The setting affects both the data bucket and the logging bucket. Default: false. |
| website | no | Map containing static web-site hosting or redirect configuration. (this website object is defined as a complex object in terraform see the example to learn how to use it) |
| acl_public | no | Boolean. If true the bucket will became public. This variable will only make an effect if no-website is defined. Alc_public = true is thought to be used with a CDN to server static content within S3 bucket. Other used could rise security risks.|
| lifecycle_rule | no | List of lifecycle rules that you want to apply to the bucket (this lifecycle rules are defined as a complex object in terraform see the example to learn how to use it) |


# Outputs
| Name | Description |
| ------ | ------ |
| data_bucket_name | The name of the S3 bucket where the actual data is stored. |
| data_bucket_arn | The ARN of the S3 bucket where the actual data is stored.  | 
| logging_bucket_name | The name of the S3 bucket where log information about the data bucket is stored. | 
| logging_bucket_arn | The ARN of the S3 bucket where log information about the data bucket is stored. |
| data_bucket_name | The name of the S3 bucket where the actual data is stored. |
| data_bucket | An object that represent the S3 bucket where the actual data is stored. |
| logging_bucket | An object that represent the S3 bucket log information about the data bucket is stored. |
